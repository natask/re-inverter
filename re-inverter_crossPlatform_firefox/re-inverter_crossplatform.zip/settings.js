chrome.storage.sync.set({
	"www.youtube.com": true,
	"en.wikipedia.org": true,
	"global_turn_off": false,
	"global_hide": false,
	"global_hue_rotate": "180"
});
